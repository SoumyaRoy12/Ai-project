#include <iostream>
#include <string>
#include <algorithm>
#include <ctime>
using namespace std;

// Convert text to LowerCase
string toLowerCase(string text) {
    transform(text.begin(), text.end(), text.begin(), ::tolower);
    return text;
}

// Greeting based on time
string getGreeting() {
    time_t now = time(0);
    tm *ltm = localtime(&now);
    int hour = ltm->tm_hour;
    if (hour < 12) return "Good morning!";
    else if (hour < 18) return "Good afternoon!";
    else return "Good evening!";
}

// Response generator
string getResponse(string userInput) {
    string text = toLowerCase(userInput);

    if (text.find("hello") != string::npos || text.find("hi") != string::npos)
        return "Hello! Welcome to Manav Rachna International Institute of Research and Studies (MRIIRS). How can I help you today?";
    
    else if (text.find("admission") != string::npos)
        return "The admission process at MRIIRS is simple:\n1️⃣ Apply online at https://apply.manavrachna.edu.in\n2️⃣ Fill out the application form and pay the fee.\n3️⃣ Appear for the MRNAT entrance test.\n4️⃣ Based on merit, you'll get admission offers.\nWould you like info about eligibility criteria?";
    
    else if (text.find("eligibility") != string::npos)
        return "Eligibility at MRIIRS varies by course:\n- For B.Tech: 10+2 with Physics, Chemistry, and Maths (minimum 50%).\n- For BBA/BCA: 10+2 in any stream with 50%.\n- For MBA: Graduation with 50% and a valid MRNAT/CAT/XAT score.";
    
    else if (text.find("courses") != string::npos)
        return "MRIIRS offers various courses:\n🎓 Engineering (B.Tech, M.Tech)\n💼 Management (BBA, MBA)\n💻 Computer Applications (BCA, MCA)\n🧠 Humanities, Science, Law, Design, and many more.";
    
    else if (text.find("placement") != string::npos)
        return "MRIIRS has excellent placement records. Top recruiters include TCS, Infosys, Deloitte, Capgemini, Amazon, and many others. The average placement rate is above 90% for eligible students.";
    
    else if (text.find("facilities") != string::npos)
        return "The campus includes modern labs, digital classrooms, a sports complex, hostel facilities, libraries, cafeterias, and innovation centers for research and startups.";
    
    else if (text.find("contact") != string::npos)
        return "You can contact MRIIRS at:\n📍 Aravalli Campus, Sector 43, Faridabad, Haryana.\n📞 Helpline: 0129-4259000\n🌐 Website: https://manavrachna.edu.in";
    
    else if (text.find("location") != string::npos)
        return "Manav Rachna University is located in Faridabad, Haryana — easily accessible from Delhi NCR.";
    
    else if (text.find("about") != string::npos)
        return "Manav Rachna International Institute of Research and Studies (MRIIRS) is a NAAC A++ accredited university offering world-class education in engineering, management, sciences, and more.";
    
    else if (text.find("bye") != string::npos)
        return "Goodbye! I hope I helped you learn about Manav Rachna University. Have a great day!";
    
    else if (text.find("thanks") != string::npos)
        return "You're most welcome! 😊";
    
    else if (text.find("help") != string::npos)
        return "Sure! You can ask me about:\n👉 Admission process\n👉 Courses offered\n👉 Facilities\n👉 Placement\n👉 Contact details\n👉 Eligibility criteria";
    
    else
        return "I'm not sure about that. You can ask me about admission, courses, placements, or facilities at MRIIRS.";
}

int main() {
    cout << "------------------------------------------------------------\n";
    cout << "🤖  Welcome to MRIIRS InfoBot - Your AI College Assistant\n";
    cout << "------------------------------------------------------------\n\n";
    cout << getGreeting() << " I'm your friendly chatbot for Manav Rachna University.\n";
    cout << "Type 'help' to know what I can answer or 'bye' to exit.\n\n";

    string userInput;
    while (true) {
        cout << "You: ";
        getline(cin, userInput);

        if (toLowerCase(userInput) == "bye") {
            cout << "MRIIRS InfoBot: " << getResponse(userInput) << endl;
            break;
        }

        cout << "MRIIRS InfoBot: " << getResponse(userInput) << "\n" << endl;
    }

    cout << "\nSession ended. Thank you for using MRIIRS InfoBot! 💬\n";
    return 0;
}